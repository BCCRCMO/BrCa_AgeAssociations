#####################################################################################
# MOutils:  Utility functions useful with R projects in the Molecular Oncology lab.
#####################################################################################

### getAnywhere() : Get objects, even those hidden in namespaces.
### str(): Maechler's equivalent of Hesterberg's describe().

"ostr" <-
  function(x)
{
  ## x   Any S object.
  ## function ostr() will do several descriptions of an object.
  ## Flaws in each function call differ, so by comparing the
  ## four outputs, one can get a reasonable sense of the object.
  ## Cleaning this up is a project for another day.

  if(length(slotNames(x))) {
    cat("\n<Class Description>\n")
    try(showClass(class(x)))
    cat("\n<End Class Description>\n\n")
  }
  
  cat("\n<Class Structure>\n")
  str(x)
  cat("\n<End Class Structure>\n\n")
  
  cat("\n<unClass Structure>\n")
  str(unclass(x))
  cat("\n<End unClass Structure>\n\n")
  
  cat("\n<describe Structure>\n")
  describe(x)
  cat("\n<End describe Structure>\n\n")
  
}
    

"describe" <-
  function(x,
           maxlen = 100,
           describeAttributes = TRUE,
           prefix = "",
           attri = FALSE,
           describeClass = TRUE)
{
  ## Note: Can also use str() function in R.
  ## Describe the structure of object x, recursively.
  ## If x is a list of length longer than maxlen, only list the names of
  ## the components.
  ## If describeAttributes = F, then only give names of attributes.
  ## Prefix and attri are intended for internal use in recursive calls.
  ## If attri then attributes are being printed, use & instead of $ or @
  ## Tim Hesterberg <timh@insightful.com>, 2/18/2000, comments welcome.


  nn <- slotNames(x)
  slotted <- length(nn) && !is.element(class(x), c("named", "structure"))

  ## Show class info
  if(slotted && describeClass) {
    cat("\n<Class Description>\n")
    try(showClass(class(x)))
    cat("\n<End Class Description>\n\n")
  }
  
  ## determine attributes to be shown
  ax <- attributes(x)
  if(!slotted) {
    ax$dim <- NULL
    ax$class <- NULL
    if(is.list(x) || class(x) != "named") ax$names <- NULL
  }
  
  ## Determine attributes to be shown separately
  ##  -- none if !describeAttributes,
  ##  -- otherwise everything but names and dimnames
  if(describeAttributes){
    ax1 <- ax[match(c("names","dimnames"), names(ax), nomatch = 0)]
    if(class(x)[1] == "named") ax1$names <- NULL
    ax2 <- ax
    ax2$names <- NULL
    ax2$dimnames <- NULL
  }
  else {
    ax1 <- ax
    ax2 <- NULL
  }

  ## SM: R mod: for environment objects.  Can not unclass env obj.
  if (mode(x) == "environment") { ux <- NULL } else { ux <- unclass(x) }
  len <- length(ux)
  if(!attri) {
    if(!slotted) {
      ## This is specific to S3 objects.
      if(mode(x) == "numeric" && is.null(dim(x)) && len == 1)
        cat(prefix,"scalar",sep = "")
      else if(is.null(x))
        cat(prefix,"NULL")
      else if(mode(x) == "package") {
        ## Need to figure out how to capture environment print name
        cat(prefix); print(x)}
      else if(mode(x) == "environment") {
        ## Need to figure out how to capture environment print name
        cat(prefix); print(x)}
      else {
        cat(prefix, mode(x),"[",sep = "")
        if(is.null(dim(x)))
          cat(" length", len)
        else
          cat(dim(x),sep = ",")
        cat("]")
      } ## No end of line yet.

      ## List class after name of object
###    if(length(oldClass(x)))
###       cat("  oldClass:", oldClass(x),"\n")
###     else
      cat("  class:", class(x),"\n")
      ## Show environment for functions
      if(is.function(x)) {cat(prefix); print(environment(x))}
    } else {
      cat(prefix, "Slotted:","[")
      cat(length(nn), ifelse(length(nn) == 1, "slot", "slots"))
      cat("]\n")
    }
  }

  ## Attributes
  if(length(ax1))
    cat(prefix, "attributes:", names(ax1), "\n")
  if(length(ax2) )
    describe(ax2, maxlen, prefix = prefix,
             describeAttributes = TRUE, attri = TRUE, describeClass = FALSE)

  if( !slotted ) {
    nn <- names(x)
    if(is.null(nn)) nn <- 1:len
  }

  if(is.list(ux) && len) {
    if(len <= maxlen) {
      nn[nn == ""] <- (1:len)[nn == ""]
      nn <- format(nn, justify = "left")
      for(i in 1:len){
        cat(prefix,
            if(attri) " &" else if(slotted) " @" else " $",
            nn[i]," ",sep = "")
        describe(ux[[i]], maxlen, prefix = paste(prefix,"  ",sep = ""),
                 describeAttributes = describeAttributes, describeClass = FALSE)
      }
    } else cat(prefix, "length > maxlen,",
               if(!slotted && is.null(names(x))) "No names" else c("names = ",nn),
               "\n")
  }
  invisible(NULL)
}



### Utility function to put up a grid editor displaying
### a dataset.  
view <- function(df)
  {
    df.aug <- cbind(RowIDX = seq(nrow(df)), df)
    invisible(edit(df.aug))
  }



"thdescribe" <-
  function(x,
           maxlen = 100,
           describeAttributes = TRUE,
           prefix = "",
           attri = FALSE){
  ## Describe the structure of object x, recursively.
  ## If x is a list of length longer than maxlen, only list the names of
  ## the components.
  ## If describeAttributes = F, then only give names of attributes.
  ## Prefix and attri are intended for internal use in recursive calls.
  ## If attri then attributes are being printed, use & instead of $ or @
  ## Tim Hesterberg <timh@insightful.com>, 2/18/2000, comments welcome.

  ## determine attributes to be shown
  ax <- attributes(x)
  ax$dim <- NULL
  ax$class <- NULL
  if(is.list(x) || class(x) != "named") ax$names <- NULL
  
  ## Determine attributes to be shown separately 
  ##  -- none if !describeAttributes,
  ##  -- otherwise everything but names and dimnames
  if(describeAttributes){
    ax1 <- ax[match(c("names","dimnames"), names(ax), nomatch = 0)]
    if(class(x) == "named") ax1$names <- NULL
    ax2 <- ax
    ax2$names <- NULL
    ax2$dimnames <- NULL
  }
  else {
    ax1 <- ax
    ax2 <- NULL
  }

  ux <- unclass(x)
  len <- length(ux)
  if(!attri){
    if(mode(x) == "numeric" && is.null(dim(x)) && len == 1)
      cat(prefix,"scalar",sep = "")
    else if(is.null(x))
      cat(prefix,"NULL")
    else {
      cat(prefix, mode(x),"[",sep = "")
      if(is.null(dim(x)))
	cat(" length", len)
      else
	cat(dim(x),sep = ",")
      cat("]")
    }					## No end of line yet.

    ## List class after name of object
    if(length(oldClass(x)))
      cat("  oldClass:", oldClass(x),"\n")
    else
      cat("  class:", class(x),"\n")
  }

  ## Attributes
  if(length(ax1))
    cat(prefix, "attributes:", names(ax1), "\n")
  if(length(ax2))
    thdescribe(ax2, maxlen, prefix = prefix, des = TRUE, attri = TRUE)

  nn <- slotNames(x)
  slotted <- length(nn) && !is.element(class(x), c("named", "structure"))
  if(!slotted){
    nn <- names(x)
    if(is.null(nn)) nn <- 1:len
  }

  if(is.list(ux) && len){
    if(len <= maxlen){
      nn[nn == ""] <- (1:len)[nn == ""]
      nn <- format(nn, justify = "left")
      for(i in 1:len){
	cat(prefix,
	    if(attri) " &" else if(slotted) " @" else " $",
	    nn[i]," ",sep = "")
	thdescribe(ux[[i]], maxlen, prefix = paste(prefix,"  ",sep = ""),
		 des = describeAttributes)
      }
    } else cat(prefix, "length > maxlen,", 
	if(!slotted && is.null(names(x))) "No names" else c("names = ",nn),
	"\n")
  }
  invisible(NULL)
}


###----------------------------------------------


count.rows <-
  function(fileName)
{
  ## scan file fileName to count rows of data.
  length(scan(file = fileName,
              what = character(0),
              blank.lines.skip = FALSE,
              quiet = TRUE,
              flush = TRUE))
}



###----------------------------------------------


iplotMA <-
  function (MA,
            array = 1,
            xlab = "A",
            ylab = "M",
            main = colnames(MA)[array], 
            xlim = NULL,
            ylim = NULL,
            status,
            values,
            pch,
            col,
            cex, 
            legend = TRUE,
            zero.weights = FALSE,
            ...) 
{
  switch(class(MA),
         RGList = {
           MA <- MA.RG(MA[, array])
           array <- 1
           x <- MA$A
           y <- MA$M
           w <- MA$w
         },
         MAList = {
           x <- as.matrix(MA$A)[, array]
           y <- as.matrix(MA$M)[, array]
           if (is.null(MA$weights)) 
             w <- NULL
           else w <- as.matrix(MA$weights)[, array]
         },
         list = {
           if (is.null(MA$A) || is.null(MA$M)) 
             stop("No data to plot")
           x <- as.matrix(MA$A)[, array]
           y <- as.matrix(MA$M)[, array]
           if (is.null(MA$weights)) 
             w <- NULL
           else w <- as.matrix(MA$weights)[, array]
         },
         MArrayLM = {
           x <- MA$Amean
           y <- as.matrix(MA$coefficients)[, array]
           if (is.null(MA$weights)) 
             w <- NULL
           else w <- as.matrix(MA$weights)[, array]
         },
         matrix = {
           narrays <- ncol(MA)
           if (narrays < 2) 
             stop("Need at least two arrays")
           if (narrays > 5) 
             x <- apply(MA, 1, median, na.rm = TRUE)
           else x <- rowMeans(MA, na.rm = TRUE)
           y <- MA[, array] - x
           w <- NULL
         },
         exprSet = {
           narrays <- ncol(MA@exprs)
           if (narrays < 2) 
             stop("Need at least two arrays")
           if (narrays > 5) 
             x <- apply(MA@exprs, 1, median, na.rm = TRUE)
           else x <- rowMeans(MA@exprs, na.rm = TRUE)
           y <- MA@exprs[, array] - x
           w <- NULL
           if (missing(main)) 
             main <- colnames(MA@exprs)[array]
         },
         stop("MA is invalid object")
         )
  if (!is.null(w) && !zero.weights) {
    i <- is.na(w) | (w <= 0)
    y[i] <- NA
  }
  if (is.null(xlim)) 
    xlim <- range(x, na.rm = TRUE)
  if (is.null(ylim)) 
    ylim <- range(y, na.rm = TRUE)
  if (missing(status)) 
    status <- MA$genes$Status
  ixyplot(x, y, xlab = xlab, ylab = ylab, main = main)
  ## abline(h = 0) ## Will have to put this in ixyplot before key legend plot

  invisible()
}



ImageplotMA <- 
function (MA, array = 1, xlab = "A", ylab = "M", main = colnames(MA)[array], 
    xlim = NULL, ylim = NULL, status, values, pch, col, cex, 
    legend = TRUE, zero.weights = FALSE, ...) 
{
    switch(class(MA), RGList = {
        MA <- MA.RG(MA[, array])
        array <- 1
        x <- MA$A
        y <- MA$M
        w <- MA$w
    }, MAList = {
        x <- as.matrix(MA$A)[, array]
        y <- as.matrix(MA$M)[, array]
        if (is.null(MA$weights)) 
            w <- NULL
        else w <- as.matrix(MA$weights)[, array]
    }, list = {
        if (is.null(MA$A) || is.null(MA$M)) 
            stop("No data to plot")
        x <- as.matrix(MA$A)[, array]
        y <- as.matrix(MA$M)[, array]
        if (is.null(MA$weights)) 
            w <- NULL
        else w <- as.matrix(MA$weights)[, array]
    }, MArrayLM = {
        x <- MA$Amean
        y <- as.matrix(MA$coefficients)[, array]
        if (is.null(MA$weights)) 
            w <- NULL
        else w <- as.matrix(MA$weights)[, array]
    }, matrix = {
        narrays <- ncol(MA)
        if (narrays < 2) 
            stop("Need at least two arrays")
        if (narrays > 5) 
            x <- apply(MA, 1, median, na.rm = TRUE)
        else x <- rowMeans(MA, na.rm = TRUE)
        y <- MA[, array] - x
        w <- NULL
    }, exprSet = {
        narrays <- ncol(MA@exprs)
        if (narrays < 2) 
            stop("Need at least two arrays")
        if (narrays > 5) 
            x <- apply(MA@exprs, 1, median, na.rm = TRUE)
        else x <- rowMeans(MA@exprs, na.rm = TRUE)
        y <- MA@exprs[, array] - x
        w <- NULL
        if (missing(main)) 
            main <- colnames(MA@exprs)[array]
    }, stop("MA is invalid object"))
    if (!is.null(w) && !zero.weights) {
        i <- is.na(w) | (w <= 0)
        y[i] <- NA
    }
    if (is.null(xlim)) 
        xlim <- range(x, na.rm = TRUE)
    if (is.null(ylim)) 
        ylim <- range(y, na.rm = TRUE)
    if (missing(status)) 
        status <- MA$genes$Status
    plot(x, y, xlab = xlab, ylab = ylab, main = main, xlim = xlim, 
        ylim = ylim, type = "n", ...)
    if (is.null(status) || all(is.na(status))) {
        if (missing(pch)) 
            pch = 16
        if (missing(cex)) 
            cex = 0.3
        Image(x, y)
    }
    else {
        if (missing(values)) {
            if (is.null(attr(status, "values"))) 
                values <- names(sort(table(status), decreasing = TRUE))
            else values <- attr(status, "values")
        }
        sel <- !(status %in% values)
        nonhi <- any(sel)
        if (nonhi) 
            Image(x[sel], y[sel])
        nvalues <- length(values)
        if (missing(pch)) {
            if (is.null(attr(status, "pch"))) 
                pch <- rep(16, nvalues)
            else pch <- attr(status, "pch")
        }
        if (missing(cex)) {
            if (is.null(attr(status, "cex"))) {
                cex <- rep(1, nvalues)
                if (!nonhi) 
                  cex[1] <- 0.3
            }
            else cex <- attr(status, "cex")
        }
        if (missing(col)) {
            if (is.null(attr(status, "col"))) {
                col <- nonhi + 1:nvalues
            }
            else col <- attr(status, "col")
        }
        pch <- rep(pch, length = nvalues)
        col <- rep(col, length = nvalues)
        cex <- rep(cex, length = nvalues)
        for (i in 1:nvalues) {
            sel <- status == values[i]
            Image(x[sel], y[sel])
        }
        if (legend) {
            if (is.list(pch)) 
                legend(x = xlim[1], y = ylim[2], legend = values, 
                  fill = col, col = col, cex = 0.9)
            else legend(x = xlim[1], y = ylim[2], legend = values, 
                pch = pch, , col = col, cex = 0.9)
        }
    }
    invisible()
}
######################################################

make.packages.html <- 
  function (lib.loc = .libPaths()) 
{
    f.tg <- file.path(tempdir(), ".R/doc/html/packages.html")
    if (!((file.exists(dirname(f.tg)) ||
           dir.create(dirname(f.tg), recursive = TRUE)) &&
          file.create(f.tg))) {
      warning("cannot create HTML package index")
      return(FALSE)
    }
    searchindex <- file.path(tempdir(), ".R/doc/html/search/index.txt")
    if (!((file.exists(dirname(searchindex)) ||
           dir.create(dirname(searchindex), recursive = TRUE)) &&
          file.create(searchindex))) {
      warning("cannot create HTML search index")
      return(FALSE)
    }
    useUTF8 <- capabilities("iconv")
    if (useUTF8) 
        file.append(f.tg, file.path(R.home("doc"), "html", "packages-head-utf8.html"))
    else file.append(f.tg, file.path(R.home("doc"), "html", "packages-head.html"))
    out <- file(f.tg, open = "a")
    search <- file(searchindex, open = "w")
    known <- character(0)
    for (lib in lib.loc) {
        cat("<p><h3>Packages in ", lib, "</h3>\n<p><table width=\"100%\" summary=\"R Package list\">\n", 
            sep = "", file = out)
        pg <- sort(.packages(all.available = TRUE, lib.loc = lib))
        for (i in pg) {
            before <- sum(i %in% known)
            link <- if (before == 0) 
                i
            else paste(i, before, sep = ".")
            from <- file.path(lib, i)
            to <- file.path(tempdir(), ".R", "library", link)
            file.symlink(from, to)
            title <- packageDescription(i, lib.loc = lib, field = "Title", 
                encoding = ifelse(useUTF8, "UTF-8", ""))
            if (is.na(title)) 
                title <- "-- Title is missing --"
            cat("<tr align=\"left\" valign=\"top\">\n", "<td width=\"25%\"><a href=\"../../library/", 
                link, "/html/00Index.html\">", i, "</a></td><td>", 
                title, "</td></tr>\n", file = out, sep = "")
            contentsfile <- file.path(from, "CONTENTS")
            if (!file.exists(contentsfile)) 
                next
            contents <- readLines(contentsfile)
            isURL <- grep("URL:", contents, fixed = TRUE, useBytes = TRUE)
            if (length(isURL) && link != i) 
                contents[isURL] <- gsub(paste("/library/", i, 
                  sep = ""), paste("/library/", link, sep = ""), 
                  contents[isURL], fixed = TRUE, useBytes = TRUE)
            writeLines(c(contents, ""), search)
        }
        cat("</table>\n\n", file = out)
        known <- c(known, pg)
    }
    cat("</body></html>\n", file = out)
    close(out)
    close(search)
    invisible(TRUE)
}

##########################################################################
bell <- function(ring = 5) {
  for(i in seq(ring)) {
    system("echo $'\a'")
  }
}

##########################################################################

### ## find the 20 largest objects in the global environment
### rev(sort(sapply(ls(), function(x) object.size(get(x)))))[1:20]
head.size <- function(pos = 1, nshow = 20) {
  if (length(ls(pos = pos))) {
    nshow <- min(nshow, length(ls(pos = pos)))
    rev(sort(sapply(ls(pos = pos),
                    function(xobj) object.size(get(xobj)))))[seq(nshow)]
  }
}
##########################################################################


"ftable2mtx" <-
function (x, file = "", quote = FALSE, append = FALSE, digits = getOption("digits")) 
{
  ## Copy of function write.ftable() modified to return
  ## a matrix, to allow printing as HTML table for use in
  ## <sigh> Word and Excel docs.
  ## See flat table documentation for ftable (package "stats").
  ## Usage:
  ##       print(xtable(ftable2mtx(ftable(xtabs(CytoPosDeadNeg ~ ftaxol + fSIRNA + fCELL, data = lncap.df)))), type = "html", file = "foo3.doc")
  ## ftable makes good printable tables from xtabs() output.
  ## Then need to make a character matrix out of the ftable object.
  ## Pass character matrix to xtable() whose print method is HTML aware.
  ## Open with Word, usual embedded cell-oriented table is in place.
  ##
  
  if (!inherits(x, "ftable")) 
    stop("'x' must be an \"ftable\" object")
  ox <- x
  charQuote <- function(s) if (quote) 
    paste("\"", s, "\"", sep = "")
  else s
  makeLabels <- function(lst) {
    lens <- sapply(lst, length)
    cplensU <- c(1, cumprod(lens))
    cplensD <- rev(c(1, cumprod(rev(lens))))
    y <- NULL
    for (i in rev(seq(along = lst))) {
      ind <- 1 + seq(from = 0, to = lens[i] - 1) * cplensD[i + 
                                 1]
      tmp <- character(length = cplensD[i])
      tmp[ind] <- charQuote(lst[[i]])
      y <- cbind(rep(tmp, times = cplensU[i]), y)
    }
    y
  }
  makeNames <- function(x) {
    nmx <- names(x)
    if (is.null(nmx)) 
      nmx <- rep("", length.out = length(x))
    nmx
  }
  xrv <- attr(x, "row.vars")
  xcv <- attr(x, "col.vars")
  LABS <- cbind(rbind(matrix("", nrow = length(xcv), ncol = length(xrv)), 
                      charQuote(makeNames(xrv)), makeLabels(xrv)), c(charQuote(makeNames(xcv)), 
                                                                     rep("", times = nrow(x) + 1)))
  DATA <- rbind(if (length(xcv)) 
                t(makeLabels(xcv)), rep("", times = ncol(x)), format(unclass(x), 
                                              digits = digits))
###     browser()
  x <- cbind(apply(LABS, 2, format, justify = "left"), apply(DATA, 
                                      2, format, justify = "right"))
###     cat(t(x), file = file, append = append, sep = c(rep(" ", 
###         ncol(x) - 1), "\n"))
  invisible(x)
}


##########################################################################

### list large objects in global env
### sapply(ls(), function(x) object.size(get(x)))
### as.matrix(rev(sort(sapply(ls(), function(x) object.size(get(x)))))[1:10])



##########################################################################
read.INCell.data <-
  function(filename, saveRdata = TRUE)
{
  ## Ensure library with excel reader function is in place.
  require(gregmisc)
  
  ## Read sheet 2 of INCell xls file
  df0 <- read.xls(filename, sheet = 2, stringsAsFactors = FALSE)
  ## Drop first three rows, extra header rows
  df1 <- df0[-c(1:3),]
  ## Drop first 2 columns
  df2 <- as.data.frame(sapply(df1[, -c(1:2)], as.numeric))
  row.names(df2) <- df1[, 1]
  df2[is.na(df2)] <- 0
  names(df2) <- make.names(names(df0)[-c(1:2)], unique = TRUE)
  if(saveRdata) {
##    save(df2, file = paste(filename, ".Rdata",
##                sep = ""))
    write.csv(df2, file = paste(filename, ".csv",
                sep = ""))
  }
  invisible(return(df2))
}




##########################################################################
## parse xdce file to obtain field coordinates.


extract.xdce.data <-
  function(filename)
{
  xcon <- file(filename, open = "r")
  on.exit(close(xcon))
  
  ## Read data until "<Image "
  labelText <- ""
  ## row pointer
  df.rowi <- 0
  ## data frame to hold x, y data
  nrow.template <- 100
  df.xy.template <-
    data.frame(
               xOffset = rep(as.numeric(NA), nrow.template),
               yOffset = rep(as.numeric(NA), nrow.template)
               )
  df.xy <- df.xy.template
  
  while(length(lineText <- readLines(xcon, n = 1))) {
    if (length(grep("^<Image ", lineText, perl = TRUE, useBytes = TRUE)) &&
        grep("^<Image ", lineText, perl = TRUE, useBytes = TRUE) == 1) {
      ## Found an image.  Increment df row pointer
      df.rowi <- df.rowi + 1
      ## Check data frame, grow if needed
      if ( df.rowi > nrow(df.xy) ) {
        ## Add more rows to df.xy
        df.xy <- rbind(df.xy, df.xy.template)
      }
      ## find line with well label and save well label
      while(length(lineText <- readLines(xcon, n = 1))) {
        if (length(lg <- grep("^<Well label ", lineText, perl = TRUE, useBytes = TRUE)) &&
            lg == 1) {
          ## Extract the well label and break
          quotePosns <- gregexpr("\"", lineText, perl = TRUE, useBytes = TRUE)
          labelText <- substr(lineText, quotePosns[[1]][1] + 1,
                              quotePosns[[1]][2] - 1)
          row.names(df.xy)[df.rowi] <- labelText
          break
        }
      }
      ## find line with offset from well center
      while(length(lineText <- readLines(xcon, n = 1))) {
        if (length(lg <- grep("^<OffsetFromWellCenter ", lineText,
                              perl = TRUE, useBytes = TRUE)) &&
            lg == 1) {
          ## Extract the well label and break
          quotePosns <- gregexpr("\"", lineText, perl = TRUE, useBytes = TRUE)
          xPosns <- gregexpr("x = \"", lineText, perl = TRUE, useBytes = TRUE)
          yPosns <- gregexpr("y = \"", lineText, perl = TRUE, useBytes = TRUE)
          xOffset <-
            as.numeric(substr(lineText,
                              quotePosns[[1]][which(quotePosns[[1]] >
                                                    xPosns[[1]])[1]] + 1,
                              quotePosns[[1]][which(quotePosns[[1]] >
                                                    xPosns[[1]])[2]] - 1))
          yOffset <-
            as.numeric(substr(lineText,
                              quotePosns[[1]][which(quotePosns[[1]] >
                                                    yPosns[[1]])[1]] + 1,
                              quotePosns[[1]][which(quotePosns[[1]] >
                                                    yPosns[[1]])[2]] - 1))
          df.xy[df.rowi, "xOffset"] <- xOffset
          df.xy[df.rowi, "yOffset"] <- yOffset

          break
        }
      }
    }
  }
  ## File completed.  Save data
  write.csv(df.xy[1:df.rowi, ], file = paste(filename, ".csv",
                                  sep = ""))
}
        

##########################################################################
## Well row, col, field number from INCell well id strings

extractWellRow <- function(WellID) {
  return(as.character(substr(as.character(WellID), 1, 1)))
}

extractWellCol <- function(WellID) {
  return(as.numeric(matrix(unlist(strsplit(
    matrix(unlist(strsplit(WellID, "-")), ncol = 2, byrow = TRUE)[, 2],
      "\\(")), ncol = 2, byrow = TRUE)[, 1]))
}

extractWellField <- function(WellID) {
  ## If WellID entries contain plate or other info beyond (fld n) portion of
  ## id, second strsplit will yield list items of length 2.  Otherwise, list
  ## elements will be of length 1.
  ncol.split2 <- length(unlist(strsplit(unlist(strsplit(WellID[1], "\\(fld"))[2], "\\)")))
  switch(as.character(ncol.split2),
         "2" = return(as.numeric(matrix(unlist(strsplit(
                  matrix(unlist(strsplit(WellID, "\\(fld")), ncol = 2, byrow = TRUE)[, 2],
                    "\\)")), ncol = ncol.split2, byrow = TRUE)[, 1])),
         "1" = return(as.numeric(unlist(strsplit(
                  matrix(unlist(strsplit(WellID, "\\(fld")), ncol = 2, byrow = TRUE)[, 2],
                    "\\)")))),
         NULL)
}

##########################################################################
## Well row, col, field number from CellProfiler well id strings

extractWellRowCP <- function(WellID) {
  return(as.character(substr(as.character(WellID), 1, 1)))
}

extractWellColCP <- function(WellID) {
  return(as.numeric(matrix(unlist(strsplit(
    matrix(unlist(strsplit(WellID, "-")), ncol = 3, byrow = TRUE)[, 2],
      "\\(")), ncol = 2, byrow = TRUE)[, 1]))
}

extractWellFieldCP <- function(WellID) {
  ## If WellID entries contain plate or other info beyond (fld n) portion of
  ## id, second strsplit will yield list items of length 2.  Otherwise, list
  ## elements will be of length 1.
  ncol.split2 <- length(unlist(strsplit(unlist(strsplit(WellID[1], "\\(fld"))[2], "wv")))
  switch(as.character(ncol.split2),
         "2" = return(as.numeric(matrix(unlist(strsplit(
                  matrix(unlist(strsplit(WellID, "\\(fld")), ncol = 2, byrow = TRUE)[, 2],
                    "wv")), ncol = ncol.split2, byrow = TRUE)[, 1])),
         "1" = return(as.numeric(unlist(strsplit(
                  matrix(unlist(strsplit(WellID, "\\(fld")), ncol = 2, byrow = TRUE)[, 2],
                    "wv")))),
         NULL)
}

##########################################################################
### utility functions for e.g. mapping in and out of the logistic universe
### when fitting binomial models.
logit <- function(p) log((p/(1-p)))
antilogit <- function(b) exp(b)/(1+exp(b))

unsqrt <- function(x) { sign(x) * (x^2) }

antilog2 <- function(x) { 2^x }
antisqrt <- function(x) { sign(x) * x * x }


### Counterpart to log2()
exp2 <-
  function(x)
{
###
### e.g.
###  > exp2(log2(16))
### [1] 16
###   
  exp(x * log(2))
}


##########################################################################
### boxplot modification to yield 5 number summary that
### approximates 1 and 2 Standard Deviation lines when
### used on normal data.


### > nsim <- 1000
### > xmat <- matrix(as.numeric(NA), nrow = nsim, ncol = 5)
### > for(ict in 1:nsim){
### +   xmat[ict, ] <- boxplot.stats(rnorm(100))$stats
### + }
### > colMeans(xmat)
### [1] -2.283047212 -0.681608883 -0.006977304  0.668491959  2.253048054
### > 
### > apply(xmat, 2, median)
### [1] -2.273012964 -0.673409004 -0.006203113  0.664105835  2.247337164
### > 
### > nsim <- 1000
### > xmat <- matrix(as.numeric(NA), nrow = nsim, ncol = 5)
### > for(ict in 1:nsim){
### +   xmat[ict, ] <- boxplot.stats(rnorm(1000))$stats
### + }
### > colMeans(xmat)
### [1] -2.6076415465 -0.6732200491 -0.0006442885  0.6722849862  2.6123927081
### > 
### > apply(xmat, 2, median)
### [1] -2.6101953918 -0.6724784249  0.0004412339  0.6725297190  2.6082403697
### So traditional boxplot produces whiskers that for standard gaussian
### data represents a 99% coverage interval
### > (1 - pnorm(2.6)) * 2
### [1] 0.009322376
### 
### 
### 




### > nsim <- 1000
### > xmat <- matrix(as.numeric(NA), nrow = nsim, ncol = 5)
### > for(ict in 1:nsim){
### +   xmat[ict, ] <- smboxplot.stats(rnorm(100), coef = 0.6, qd = 3)$stats
### + }
### > colMeans(xmat)
### [1] -1.966208443 -0.974920521 -0.006526123  0.967427935  1.950392092
### >
### >  nsim <- 1000
### >  xmat <- matrix(as.numeric(NA), nrow = nsim, ncol = 5)
### >  for(ict in 1:nsim){
### +    xmat[ict, ] <- smboxplot.stats(rnorm(1000), coef = 0.54, qd = 3)$stats
### +  }
### >  colMeans(xmat)
### [1] -1.9935172337 -0.9667425036 -0.0005582619  0.9692879005  1.9966579346
### > apply(xmat, 2, median)
### [1] -1.992533732 -0.966082369 -0.001935110  0.967344306  1.997925732


smfivenum <-
  function (x,  na.rm = TRUE, qd = 3.0) 
{
  ## Tukey boxplot uses qd = 2
    xna <- is.na(x)
    if (na.rm) 
        x <- x[!xna]
    else if (any(xna)) 
        return(rep.int(NA, 5))
    x <- sort(x)
    n <- length(x)
    if (n == 0) 
        rep.int(NA, 5)
    else {
        n4 <- floor((n + 3)/qd)/2
        d <- c(1, n4, (n + 1)/2, n + 1 - n4, n)
        0.5 * (x[floor(d)] + x[ceiling(d)])
    }
}

smboxplot.stats <-
function (x, coef = 0.54, do.conf = TRUE, do.out = TRUE, ...) 
{
  ## Tukey boxplot uses coef = 1.5
    if (coef < 0) 
        stop("'coef' must not be negative")
    nna <- !is.na(x)
    n <- sum(nna)
    stats <- smfivenum(x, na.rm = TRUE, ...)
    ## At this point stats[1] is 1 and stats[5] is n
    ## so that the min and max values will define the
    ## position of the whisker ends.
    iqr <- diff(stats[c(2, 4)])
    if (coef == 0) 
        do.out <- FALSE
    else {
      ## Identify 'outliers':  any points that exceed the
      ## upper and lower 'extremes'.
        out <- if (!is.na(iqr)) {
            x < (stats[2] - coef * iqr) | x > (stats[4] + coef * 
                iqr)
        }
        else !is.finite(x)
        ## Now redefine the whisker ends to those data values
        ## that are not outliers.
        if (any(out[nna], na.rm = TRUE)) 
            stats[c(1, 5)] <- range(x[!out], na.rm = TRUE)
    }
    conf <- if (do.conf) 
        stats[3] + c(-1.58, 1.58) * iqr/sqrt(n)
    list(stats = stats, n = n, conf = conf, out = if (do.out) x[out & 
        nna] else numeric(0))
}


##########################################################################
###
### Added smlegend function, for use in adding legends
### with control over legend line display - longer lines, thicker etc.
### 
smlegend <- 
function (x, y = NULL, legend, fill = NULL, col = par("col"), 
    lty, lwd, pch, angle = 45, density = NULL, bty = "o", bg = par("bg"), 
    box.lwd = par("lwd"), box.lty = par("lty"), pt.bg = NA, cex = 1, 
    pt.cex = cex, pt.lwd = lwd, xjust = 0, yjust = 1, x.intersp = 1, 
    y.intersp = 1, adj = c(0, 0.5), text.width = NULL, text.col = par("col"), 
    merge = do.lines && has.pch, trace = FALSE, plot = TRUE, 
    ncol = 1, horiz = FALSE, title = NULL, inset = 0, smlinelength = 1) 
{
    if (missing(legend) && !missing(y) && (is.character(y) || 
        is.expression(y))) {
        legend <- y
        y <- NULL
    }
    mfill <- !missing(fill) || !missing(density)
    if (length(title) > 1) 
        stop("invalid title")
    n.leg <- if (is.call(legend)) 
        1
    else length(legend)
    if (n.leg == 0) 
        stop("'legend' is of length 0")
    auto <- if (is.character(x)) 
        match.arg(x, c("bottomright", "bottom", "bottomleft", 
            "left", "topleft", "top", "topright", "right", "center"))
    else NA
    if (is.na(auto)) {
        xy <- xy.coords(x, y)
        x <- xy$x
        y <- xy$y
        nx <- length(x)
        if (nx < 1 || nx > 2) 
            stop("invalid coordinate lengths")
    }
    else nx <- 0
    xlog <- par("xlog")
    ylog <- par("ylog")
    rect2 <- function(left, top, dx, dy, density = NULL, angle, 
        ...) {
        r <- left + dx
        if (xlog) {
            left <- 10^left
            r <- 10^r
        }
        b <- top - dy
        if (ylog) {
            top <- 10^top
            b <- 10^b
        }
        rect(left, top, r, b, angle = angle, density = density, 
            ...)
    }
    segments2 <- function(x1, y1, dx, dy, ...) {
        x2 <- x1 + dx
        if (xlog) {
            x1 <- 10^x1
            x2 <- 10^x2
        }
        y2 <- y1 + dy
        if (ylog) {
            y1 <- 10^y1
            y2 <- 10^y2
        }
        segments(x1, y1, x2, y2, ...)
    }
    points2 <- function(x, y, ...) {
        if (xlog) 
            x <- 10^x
        if (ylog) 
            y <- 10^y
        points(x, y, ...)
    }
    text2 <- function(x, y, ...) {
        if (xlog) 
            x <- 10^x
        if (ylog) 
            y <- 10^y
        text(x, y, ...)
    }
    if (trace) 
        catn <- function(...) do.call("cat", c(lapply(list(...), 
            formatC), list("\n")))
    cin <- par("cin")
    Cex <- cex * par("cex")
    if (is.null(text.width)) 
        text.width <- max(abs(strwidth(legend, units = "user", 
            cex = cex)))
    else if (!is.numeric(text.width) || text.width < 0) 
        stop("'text.width' must be numeric, >= 0")
    text.width <- text.width * smlinelength
    xc <- Cex * xinch(cin[1], warn.log = FALSE)
    yc <- Cex * yinch(cin[2], warn.log = FALSE)
    if (xc < 0) 
        text.width <- -text.width
    xchar <- xc
    xextra <- 0
    yextra <- yc * (y.intersp - 1)
    ymax <- yc * max(1, strheight(legend, units = "user", cex = cex)/yc)
    ychar <- yextra + ymax
    if (trace) 
        catn("  xchar=", xchar, "; (yextra,ychar)=", c(yextra, 
            ychar))
    if (mfill) {
        xbox <- xc * 0.8
        ybox <- yc * 0.5
        dx.fill <- xbox
    }
    do.lines <- (!missing(lty) && (is.character(lty) || any(lty > 
        0))) || !missing(lwd)
    n.legpercol <- if (horiz) {
        if (ncol != 1) 
            warning("horizontal specification overrides: Number of columns := ", 
                n.leg)
        ncol <- n.leg
        1
    }
    else ceiling(n.leg/ncol)
    if (has.pch <- !missing(pch) && length(pch) > 0) {
        if (is.character(pch) && !is.na(pch[1]) && nchar(pch[1], 
            type = "c") > 1) {
            if (length(pch) > 1) 
                warning("not using pch[2..] since pch[1] has multiple chars")
            np <- nchar(pch[1], type = "c")
            pch <- substr(rep.int(pch[1], np), 1:np, 1:np)
        }
        if (!merge) 
            dx.pch <- x.intersp/2 * xchar
    }
    x.off <- if (merge) 
        -0.7
    else 0
    if (is.na(auto)) {
        if (xlog) 
            x <- log10(x)
        if (ylog) 
            y <- log10(y)
    }
    if (nx == 2) {
        x <- sort(x)
        y <- sort(y)
        left <- x[1]
        top <- y[2]
        w <- diff(x)
        h <- diff(y)
        w0 <- w/ncol
        x <- mean(x)
        y <- mean(y)
        if (missing(xjust)) 
            xjust <- 0.5
        if (missing(yjust)) 
            yjust <- 0.5
    }
    else {
        h <- (n.legpercol + (!is.null(title))) * ychar + yc
        w0 <- text.width + (x.intersp + 1) * xchar
        if (mfill) 
            w0 <- w0 + dx.fill
        if (has.pch && !merge) 
            w0 <- w0 + dx.pch
        if (do.lines) 
            w0 <- w0 + (2 + x.off) * xchar
        w <- ncol * w0 + 0.5 * xchar
        if (!is.null(title) && (tw <- strwidth(title, units = "user", 
            cex = cex) + 0.5 * xchar) > w) {
            xextra <- (tw - w)/2
            w <- tw
        }
        if (is.na(auto)) {
            left <- x - xjust * w
            top <- y + (1 - yjust) * h
        }
        else {
            usr <- par("usr")
            inset <- rep(inset, length.out = 2)
            insetx <- inset[1] * (usr[2] - usr[1])
            left <- switch(auto, bottomright = , topright = , 
                right = usr[2] - w - insetx, bottomleft = , left = , 
                topleft = usr[1] + insetx, bottom = , top = , 
                center = (usr[1] + usr[2] - w)/2)
            insety <- inset[2] * (usr[4] - usr[3])
            top <- switch(auto, bottomright = , bottom = , bottomleft = usr[3] + 
                h + insety, topleft = , top = , topright = usr[4] - 
                insety, left = , right = , center = (usr[3] + 
                usr[4] + h)/2)
        }
    }
    if (plot && bty != "n") {
        if (trace) 
            catn("  rect2(", left, ",", top, ", w=", w, ", h=", 
                h, ", ...)", sep = "")
        rect2(left, top, dx = w, dy = h, col = bg, density = NULL, 
            lwd = box.lwd, lty = box.lty)
    }
    xt <- left + xchar + xextra + (w0 * rep.int(0:(ncol - 1), 
        rep.int(n.legpercol, ncol)))[1:n.leg]
    yt <- top - 0.5 * yextra - ymax - (rep.int(1:n.legpercol, 
        ncol)[1:n.leg] - 1 + (!is.null(title))) * ychar
    if (mfill) {
        if (plot) {
            fill <- rep(fill, length.out = n.leg)
            rect2(left = xt, top = yt + ybox/2, dx = xbox, dy = ybox, 
                col = fill, density = density, angle = angle, 
                border = "black")
        }
        xt <- xt + dx.fill
    }
    if (plot && (has.pch || do.lines)) 
        col <- rep(col, length.out = n.leg)
    if (missing(lwd)) 
        lwd <- par("lwd")
    if (do.lines) {
        seg.len <- 2
        if (missing(lty)) 
            lty <- 1
        lty <- rep(lty, length.out = n.leg)
        lwd <- rep(lwd, length.out = n.leg)
        ok.l <- !is.na(lty) & (is.character(lty) | lty > 0)
        if (trace) 
            catn("  segments2(", xt[ok.l] + x.off * xchar, ",", 
                yt[ok.l], ", dx=", seg.len * xchar, ", dy=0, ...)")
        if (plot) 
            segments2(xt[ok.l] + x.off * xchar, yt[ok.l], dx = seg.len * 
                xchar * smlinelength, dy = 0, lty = lty[ok.l], lwd = lwd[ok.l], 
                col = col[ok.l])
        xt <- xt + (seg.len + x.off) * xchar * smlinelength
    }
    if (has.pch) {
        pch <- rep(pch, length.out = n.leg)
        pt.bg <- rep(pt.bg, length.out = n.leg)
        pt.cex <- rep(pt.cex, length.out = n.leg)
        pt.lwd <- rep(pt.lwd, length.out = n.leg)
        ok <- !is.na(pch) & (is.character(pch) | pch >= 0)
        x1 <- (if (merge) 
            xt - (seg.len/2) * xchar
        else xt)[ok]
        y1 <- yt[ok]
        if (trace) 
            catn("  points2(", x1, ",", y1, ", pch=", pch[ok], 
                ", ...)")
        if (plot) 
            points2(x1, y1, pch = pch[ok], col = col[ok], cex = pt.cex[ok], 
                bg = pt.bg[ok], lwd = pt.lwd[ok])
        if (!merge) 
            xt <- xt + dx.pch
    }
    xt <- xt + x.intersp * xchar * smlinelength
    if (plot) {
        if (!is.null(title)) 
            text2(left + w/2, top - ymax, labels = title, adj = c(0.5, 
                0), cex = cex, col = text.col)
        text2(xt, yt, labels = legend, adj = adj, cex = cex, 
            col = text.col)
    }
    invisible(list(rect = list(w = w, h = h, left = left, top = top), 
        text = list(x = xt, y = yt)))
}
### <environment: namespace:graphics>
### > 



##########################################################################
###

### Added normalize.grouped.AffyBatch.quantiles
### to allow quantile normalization of user specified
### groups of chip data before RMA or other background correction
### processing.

normalize.grouped.AffyBatch.quantiles <-
function (abatch,
          groupColumns,
          type = c("separate", "pmonly", "mmonly", "together")) 
{
    type <- match.arg(type)
    if ((type == "pmonly") | (type == "separate")) {
        pms <- unlist(pmindex(abatch))
        noNA <-
          rowSums(is.na(intensity(abatch)[pms, groupColumns, drop = FALSE])) == 0
        pms <- pms[noNA]
        intensity(abatch)[pms, groupColumns] <-
          normalize.quantiles(intensity(abatch)[pms, groupColumns,
                                                drop = FALSE], copy = FALSE)
    }
    if ((type == "mmonly") | (type == "separate")) {
        mms <- unlist(mmindex(abatch))
        noNA <-
          rowSums(is.na(intensity(abatch)[mms, groupColumns, drop = FALSE])) == 0
        mms <- mms[noNA]
        intensity(abatch)[mms, groupColumns] <-
          normalize.quantiles(intensity(abatch)[mms, groupColumns,
                                                drop = FALSE], copy = FALSE)
    }
    if (type == "together") {
        pms <- unlist(indexProbes(abatch, "both"))
        intensity(abatch)[pms, groupColumns] <-
          normalize.quantiles(intensity(abatch)[pms, groupColumns,
                                                drop = FALSE], copy = FALSE)
    }
    return(abatch)
}

##########################################################################
###

## Set up device-independent win.graph() function

graph.win <- function(...) {
  if (exists("is.R") && is.function(is.R) && is.R()) {
    ## R-specific code
    switch(Sys.info()["sysname"],
           Darwin = {##require("CarbonEL") 20140313 No longer required.
                     quartz(...)
                   },
           Windows = {win.graph(...)},
           Linux = {X11(...)}
           )
  } else {
    ## S-PLUS Windows
    win.graph(...)
  }
}

win.graph <-
  try(switch(Sys.info()["sysname"],
         Darwin = {
           switch(Sys.getenv("EMACS"),
                  t = {
                    function(width = 8, height = 6) {
                      require("graphics")
                      ## require("CarbonEL")
                      quartz()
                    }
                  },
                  function(width = 8, height = 6) quartz()
                  )
         },
         Linux = {
           grDevices::X11
         },
         Windows = {
           win.graph
         }
         )
      )
### See
###  /Volumes/KilroyHD/kilroy/Software/R/Doc/ProgrammingMethods/PlatformIndependent:
###  DetermineCommandLineEnvironmentInfo.txt
### for more details

##########################################################################
###


### heat map
### image()
### show average value for each well. cm.colors(100)
### > image.z.mat <- t(matrix(agg.df$mean.rfu, nrow = 8, ncol = 12))[, rev(seq(8))]
### require(CarbonEL)

heatmap.96well <-
  function(wellData, titleText)
{
  image.out <- image(x = 1:12, y = 1:8,
                     z = wellData, col = cm.colors(100),
                     xaxt = "n", yaxt = "n", xlim = c(0, 16), ylim = c(0, 9),
                     ylab = "Row", xlab = "Column")
  axis(side = 1, at = 1:12, labels = 1:12, cex.axis = 0.9)
  axis(side = 2, at = 1:8, labels = rev(LETTERS[1:8]), las = 1, cex.axis = 0.9)
  require(plotrix)
  color.legend(xl = 13, xr = 14, yb = 2, yt = 7, rect.col = cm.colors(100),
               legend = trunc(range(wellData)), gradient = "y", align = "rb")
  title(main = titleText)
}

##########################################################################
###


##########################################################################
###


### heat map
### image()
### show average value for each well. cm.colors(100)
### > image.z.mat <- t(matrix(agg.df$mean.rfu, nrow = 8, ncol = 12))[, rev(seq(8))]
### require(CarbonEL)

heatmap.384well <-
  function(wellData, titleText, zlim = trunc(range(wellData)))
{
  ## User hands in matrix in same orientation that
  ## it is to be plotted.
  ## image() rotates the data counterclockwise
  ## 90 degrees - so transpose and reverse column order
  ## before handing data off to image().
  ## Then, user input matrix orientation matches
  ## output plot orientation.  Upper left corner of
  ## wellData appears in upper left corner of plot.
  image.out <- image(x = 1:24, y = 1:16,
                     z = t(wellData)[, rev(seq(16))], col = cm.colors(100),
                     xaxt = "n", yaxt = "n", xlim = c(0, 29), ylim = c(0, 18),
                     ylab = "Row", xlab = "Column", zlim=zlim)
  axis(side = 1, at = 1:24, labels = 1:24, cex.axis = 0.9)
  axis(side = 2, at = 1:16, labels = rev(LETTERS[1:16]), las = 1, cex.axis = 0.9)
  require(plotrix)
  color.legend(xl = 13+12, xr = 14+12, yb = 2, yt = 7, rect.col = cm.colors(100),
               legend = zlim, #trunc(range(wellData)),
               gradient = "y", align = "rb")
  title(main = titleText)
}

##########################################################################
###


##########################################################################
##########################################################################


### heat map
### image()
### show average value for each well. cm.colors(100)
### > image.z.mat <- t(matrix(agg.df$mean.rfu, nrow = 8, ncol = 12))[, rev(seq(8))]
### require(CarbonEL)

#Legend not working
## See example in
## /Volumes/KilroyHD/kilroy/Projects/GPEC/SamLeung/HER2/20070703/email02/her2_cut_pt_2007-07-03/her2_cutpt/0.6to10/her2_cut_point_cox_all_w_copyNumber.SMmods.R

heatmap.sm <-
  function(zData, titleText, zlim = trunc(range(zData)),
           xData = seq(ncol(zData)), yData = seq(nrow(zData)),
           xLabels = xData, yLabels = yData
             )
{
  ## User hands in matrix in same orientation that
  ## it is to be plotted.
  ## image() rotates the data counterclockwise
  ## 90 degrees - so transpose and reverse column order
  ## before handing data off to image().
  ## Then, user input matrix orientation matches
  ## output plot orientation.  Upper left corner of
  ## zData appears in upper left corner of plot.

  image.out <- image(x = xData, y = yData,
                     z = t(zData)[, rev(seq(nrow(zData)))], col = cm.colors(100),
                     xaxt = "n", yaxt = "n",
                     xlim = c(0, 1.25*max(xData)),
                     ylim = c(0, 1.15*max(yData)),
                     ylab = "Row", xlab = "Column", zlim=zlim)
  axis(side = 1, at = xData, labels = as.character(xLabels),
       cex.axis = 0.9)
  axis(side = 2, at = yData, labels = as.character(rev(yLabels)), las = 1,
       cex.axis = 0.9)
  require(plotrix)
  color.legend(xl = 1.05*max(xData),
               xr = 1.15*max(xData),
               yb = (min(yData) + .125*(diff(range(yData)))),
               yt = (min(yData) + .5*(diff(range(yData)))),
               rect.col = rev(cm.colors(100)),
               legend = zlim, #trunc(range(zData)),
               gradient = "y", align = "rb")
  title(main = titleText)
  invisible()
}

##########################################################################
###
#### Calculate biweight midcovariance
####   from Wilcox (1997).

bicov<-function(x, y){
mx <- median(x)
my <-median(y)
ux <- abs((x - mx)/(9 * qnorm(0.75) * mad(x)))
uy <- abs((y - my)/(9 * qnorm(0.75) * mad(y)))
aval <- ifelse(ux <= 1, 1, 0)
bval <- ifelse(uy <= 1, 1, 0)
top <- sum(aval * (x - mx) * (1 - ux^2)^2 * bval * (y - my) * (1 - uy^2)^2)
top <- length(x) * top
botx <- sum(aval * (1 - ux^2) * (1 - 5 * ux^2))
boty <- sum(bval * (1 - uy^2) * (1 - 5 * uy^2))
bi <- top/(botx * boty)
bi
}

#### Calculate biweight midcorrelation.

bicor<-function(x,y){
x <-as.numeric(x)
y<-as.numeric(y)
bicov(x,y)/(sqrt(bicov(x,x)*bicov(y,y)))
}



##########################################################################
###############################################################################################

# helper function - by Robert Gentleman (http://tolstoy.newcastle.edu.au/R/help/01c/2809.html)

getPval <- function(x) 

{ 

  if( is.matrix(x$obs)) 

    etmp <- apply(x$exp, 1, sum) 

  else 

    etmp <- x$exp 

  df<- (sum(1 * (etmp > 0))) - 1 

  pv <- 1 - pchisq(x$chisq, df) 

 pv 

} 

################################################################################################


date.ddmmyyyy <- 
  function (sdate, sep = "/") 
{
  require("date")
  temp <- date.mdy(sdate)
  ifelse(is.na(sdate), "NA",
         paste(temp$day, temp$month, temp$year, 
               sep = sep))
}

### Kurt.Hornik@R-project.org
summary.date <-
  function (object, ...) 
{
  y <- as.character(range(object, ...))
  names(y) <- c("First ", "Last  ")
  y
}

date.ddmmmyyyy <-
  function (sdate) 
{
  require("date")
  temp <- date.mdy(sdate)
  month <- month.abb[temp$month]
  ifelse(is.na(sdate), as.character(NA), paste(temp$day, month, 
                                               temp$year, sep = ""))
}
##########################################################################

## a useful function: rev() for strings
strReverse <- function(x)
        sapply(lapply(strsplit(x, NULL), rev), paste, collapse="")

leftPad0 <- function(x,
                     length = max(nchar(x)))
{
  ### Note:  for numeric data, formatC(numbervec, width = 3, flag = "0")
  ###        will left-pad numerics with zeroes.
  if ( is.numeric(x) ) {
    return( formatC(x, width = length, flag = "0") )
  } else {
    zeroes <- paste(rep("0", length), collapse = "")
    return( strReverse(substring(strReverse(paste(zeroes, x, sep = "")), 1, length)) )
  }
}

strtriml <- function(x, width.) { return(strReverse(strtrim(strReverse(x), width = width.))) }


##########################################################################
##########################################################################


### Set up a 'rubberbanding' function
### input
### - data matrix
### output
### - structure that can be plotted with components
### -- which data rows are selected

outerband <-
  function(x, coef. = 0.5, qd. = 9.0)
{
  x.xdata <- x[, 1]
  x.ydata <- x[, 2]
  x.xrange <- diff(range(x.xdata, na.rm = TRUE))
  x.yrange <- diff(range(x.ydata, na.rm = TRUE))
  x.xmin <- min(x.xdata, na.rm = TRUE) - 0.10 * x.xrange
  x.ymin <- min(x.ydata, na.rm = TRUE) - 0.10 * x.yrange
  x.xmax <- max(x.xdata, na.rm = TRUE) + 0.10 * x.xrange
  x.ymax <- max(x.ydata, na.rm = TRUE) + 0.10 * x.yrange

  x.xints <-
    c(x.xmin, smboxplot.stats(x.xdata, coef = coef., qd = qd.)$stats, x.xmax)
  x.yints <-
    c(x.ymin, smboxplot.stats(x.ydata, coef = coef., qd = qd.)$stats, x.ymax)

  x.out <- list(x = x,
                xints = x.xints,
                yints = x.yints
                )
  class(x.out) <- "outerband"
  return(x.out)
}

plot.outerband <-
  function(x,
           xlab. = "X",
           ylab. = "Y",
           main. = "",
           col. = "red",
           plot. = TRUE,
           obcol = par("col"),
           oblty = par("lty"),
           oblwd = par("lwd"),
           ...)
{

  x.xdata <- x$x[, 1]
  x.ydata <- x$x[, 2]
  x.urslope <- ((rev(x$yints)[3] - rev(x$yints)[2]) /
                     (rev(x$xints)[2] - rev(x$xints)[3]))
  x.urintc <- rev(x$yints)[2] - x.urslope*rev(x$xints)[3]
  x.ulslope <- ((rev(x$yints)[2] - rev(x$yints)[3]) /
                     ((x$xints)[3] - (x$xints)[2]))
  x.ulintc <- rev(x$yints)[3] - x.ulslope*(x$xints)[2]

  x.llslope <- (((x$yints)[3] - (x$yints)[2]) /
                     ((x$xints)[2] - (x$xints)[3]))
  x.llintc <- (x$yints)[2] - x.llslope*(x$xints)[3]

  x.lrslope <- (((x$yints)[2] - (x$yints)[3])/
                     (rev(x$xints)[3] - rev(x$xints)[2]))
  x.lrintc <- (x$yints)[2] - x.lrslope*rev(x$xints)[3]

  big.out <-
    (
      ## upper left
     ( (x.xdata < x$xints[2]) &
       (x.ydata > rev(x$yints)[3]) ) | 
     ## upper mid left
     ( (x.xdata > x$xints[2] &
        x.xdata < x$xints[3]) &
       ((x.ydata -
        (x.ulslope * x.xdata + x.ulintc)) > 0) ) | 
     ## upper ctr
     ( x.ydata > rev(x$yints)[2]) | 
     ## upper mid right
     ( (x.xdata > rev(x$xints)[3] &
        x.xdata < rev(x$xints)[2]) &
       ((x.ydata -
        (x.urslope * x.xdata + x.urintc)) > 0) ) | 
     ## upper outer right
     ( (x.xdata > rev(x$xints)[2]) &
       (x.ydata > rev(x$yints)[3]) ) 
   )

  sml.out <-
    (
     ( (x.xdata < (x$xints)[2]) &
       (x.ydata < (x$yints)[3]) ) | ## lower left
     
     ( (x.xdata > (x$xints)[2] &
        x.xdata < (x$xints)[3]) &
       ((x.ydata -
        (x.llslope * x.xdata + x.llintc)) < 0) ) | ## lower mid left

     ( x.ydata < (x$yints)[2]) | ## lower ctr
     
     ( (x.xdata > rev(x$xints)[3] &
        x.xdata < rev(x$xints)[2]) &
       ((x.ydata -
        (x.lrslope * x.xdata + x.lrintc)) < 0) ) | ## lower mid right

     ( (x.xdata > rev(x$xints)[2]) &
       (x.ydata < (x$yints)[3]) ) ## lower right
     )

  if (plot.) {
    plot(x$x[, 1], x$x[, 2], xlab = xlab., ylab = ylab., main = main., ...)
    abline(v = x$xints)
    abline(h = x$yints)
    ## upper left
    segments(x$xints[1], rev(x$yints)[3],
             x$xints[2], rev(x$yints)[3],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## upper mid left
    segments((x$xints)[2], rev(x$yints)[3],
             (x$xints)[3], rev(x$yints)[2],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## upper mid
    segments(x$xints[3], rev(x$yints)[2],
             rev(x$xints)[3], rev(x$yints)[2],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## upper mid right
    segments(rev(x$xints)[3], rev(x$yints)[2],
             rev(x$xints)[2], rev(x$yints)[3],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## upper right
    segments(rev(x$xints)[2], rev(x$yints)[3],
             rev(x$xints)[1], rev(x$yints)[3],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## lower left
    segments(x$xints[1], x$yints[3],
             x$xints[2], x$yints[3],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## lower mid left
    segments((x$xints)[3], (x$yints)[2],
             (x$xints)[2], (x$yints)[3],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## lower mid
    segments(x$xints[3], (x$yints)[2],
             rev(x$xints)[3], (x$yints)[2],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## lower mid right
    segments(rev(x$xints)[2], (x$yints)[3],
             rev(x$xints)[3], (x$yints)[2],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## lower right
    segments(rev(x$xints)[2], (x$yints)[3],
             rev(x$xints)[1], (x$yints)[3],
             col = obcol,
             lty = oblty, lwd = oblwd)
    points(x.xdata[big.out], x.ydata[big.out],
           col = col.)

    points(x.xdata[sml.out], x.ydata[sml.out],
           col = col.)
  }

###   sum(big.out + sml.out) ## 

  invisible(which(big.out | sml.out))

}

lines.outerband <-
  function(x,
           xlab. = "X",
           ylab. = "Y",
           main. = "",
           col. = "red",
           plot. = FALSE,
           obcol = par("col"),
           oblty = par("lty"),
           oblwd = par("lwd"),
           ...)
{

  x.xdata <- x$x[, 1]
  x.ydata <- x$x[, 2]
  x.urslope <- ((rev(x$yints)[3] - rev(x$yints)[2]) /
                     (rev(x$xints)[2] - rev(x$xints)[3]))
  x.urintc <- rev(x$yints)[2] - x.urslope*rev(x$xints)[3]
  x.ulslope <- ((rev(x$yints)[2] - rev(x$yints)[3]) /
                     ((x$xints)[3] - (x$xints)[2]))
  x.ulintc <- rev(x$yints)[3] - x.ulslope*(x$xints)[2]

  x.llslope <- (((x$yints)[3] - (x$yints)[2]) /
                     ((x$xints)[2] - (x$xints)[3]))
  x.llintc <- (x$yints)[2] - x.llslope*(x$xints)[3]

  x.lrslope <- (((x$yints)[2] - (x$yints)[3])/
                     (rev(x$xints)[3] - rev(x$xints)[2]))
  x.lrintc <- (x$yints)[2] - x.lrslope*rev(x$xints)[3]

  big.out <-
    (
      ## upper left
     ( (x.xdata < x$xints[2]) &
       (x.ydata > rev(x$yints)[3]) ) | 
     ## upper mid left
     ( (x.xdata > x$xints[2] &
        x.xdata < x$xints[3]) &
       ((x.ydata -
        (x.ulslope * x.xdata + x.ulintc)) > 0) ) | 
     ## upper ctr
     ( x.ydata > rev(x$yints)[2]) | 
     ## upper mid right
     ( (x.xdata > rev(x$xints)[3] &
        x.xdata < rev(x$xints)[2]) &
       ((x.ydata -
        (x.urslope * x.xdata + x.urintc)) > 0) ) | 
     ## upper outer right
     ( (x.xdata > rev(x$xints)[2]) &
       (x.ydata > rev(x$yints)[3]) ) 
   )

  sml.out <-
    (
     ( (x.xdata < (x$xints)[2]) &
       (x.ydata < (x$yints)[3]) ) | ## lower left
     
     ( (x.xdata > (x$xints)[2] &
        x.xdata < (x$xints)[3]) &
       ((x.ydata -
        (x.llslope * x.xdata + x.llintc)) < 0) ) | ## lower mid left

     ( x.ydata < (x$yints)[2]) | ## lower ctr
     
     ( (x.xdata > rev(x$xints)[3] &
        x.xdata < rev(x$xints)[2]) &
       ((x.ydata -
        (x.lrslope * x.xdata + x.lrintc)) < 0) ) | ## lower mid right

     ( (x.xdata > rev(x$xints)[2]) &
       (x.ydata < (x$yints)[3]) ) ## lower right
     )

  if (plot.) {
    plot(x$x[, 1], x$x[, 2], xlab = xlab., ylab = ylab., main = main., ...)
  }

    abline(v = x$xints)
    abline(h = x$yints)
    ## upper left
    segments(x$xints[1], rev(x$yints)[3],
             x$xints[2], rev(x$yints)[3],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## upper mid left
    segments((x$xints)[2], rev(x$yints)[3],
             (x$xints)[3], rev(x$yints)[2],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## upper mid
    segments(x$xints[3], rev(x$yints)[2],
             rev(x$xints)[3], rev(x$yints)[2],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## upper mid right
    segments(rev(x$xints)[3], rev(x$yints)[2],
             rev(x$xints)[2], rev(x$yints)[3],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## upper right
    segments(rev(x$xints)[2], rev(x$yints)[3],
             rev(x$xints)[1], rev(x$yints)[3],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## lower left
    segments(x$xints[1], x$yints[3],
             x$xints[2], x$yints[3],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## lower mid left
    segments((x$xints)[3], (x$yints)[2],
             (x$xints)[2], (x$yints)[3],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## lower mid
    segments(x$xints[3], (x$yints)[2],
             rev(x$xints)[3], (x$yints)[2],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## lower mid right
    segments(rev(x$xints)[2], (x$yints)[3],
             rev(x$xints)[3], (x$yints)[2],
             col = obcol,
             lty = oblty, lwd = oblwd)
    ## lower right
    segments(rev(x$xints)[2], (x$yints)[3],
             rev(x$xints)[1], (x$yints)[3],
             col = obcol,
             lty = oblty, lwd = oblwd)
    points(x.xdata[big.out], x.ydata[big.out],
           col = col.)

    points(x.xdata[sml.out], x.ydata[sml.out],
           col = col.)

###   sum(big.out + sml.out) ## 

  invisible(which(big.out | sml.out))

}

##########################################################################
##########################################################################

### Functions to allow RODBC and (DBI, RMySQL) libraries
### to behave similarly.
### RODBC has had problems operating on Mac OS X, but works in Windows
### and Linux.
### The following functions are an attempt to
### allow code written using library("RODBC")
### to work in Mac OS X.
### Frequent modifications to local procedures and to
### R libraries make this goal a moving target, and these
### functions require periodic review and revision.


### From
### /Volumes/KilroyHD/kilroy/Projects/SMcode/R.MOlab/database.funs.R
### June 2008 Mac OS X variants until RODBC fixes worked out.


  odbcClose <-
    function(conn., ...)
      {
        require("RODBC")
        require("DBI")
    
        dbDisconnect(conn., ...)
      }
  
  odbcConnect <-
    function(dsn., uid. = "mysql", pwd. = "", ...)
      {
        require("RODBC")
        require("DBI")
        require("RMySQL")
        RODBC.dbDriver <- dbDriver("MySQL")
        if(length(grep("shannon", dsn.))) {
          return(dbConnect(drv = RODBC.dbDriver,
                           user=uid.,
                           password=pwd.,
                           host="shannon.cluster.bccrc.ca",
                           dbname="CellCycleDapiBrdu" ))
        }
        if (length(grep("rocinante", dsn.))) {
          return(dbConnect(drv = RODBC.dbDriver,
                           user = uid.,
                           password = "mysql",
                           host="rocinante.bccrc.ca",
                           dbname="testcellprofiler" ))
        }
        return(-1)
      }

  ## Need a method for "<" for class "MySQLConnection"
  "<.MySQLConnection" <-
    function(x, y)
      {
        return(FALSE)
      }
  
  "close.MySQLConnection" <-
    function(x)
      {
        require("RODBC")
        require("DBI")
        require("RMySQL")
        dbDisconnect(x)
      }

  sqlQuery <-
    function( dbChannel., queryImageString. , ...)
      {
        require("RODBC")
        require("DBI")
        require("RMySQL")
        fetch(dbSendQuery(con = dbChannel., statement = queryImageString. ), n = -1)
      }


if (Sys.info()[1] == "Linux") {
  odbcConnect <- 
    function (dsn, uid = "mysql", pwd = "", ...) 
      {
        st <- paste("DSN=", dsn, sep = "")
        if (nchar(uid)) 

          st <- paste(st, ";UID=", uid, sep = "")
        if (nchar(pwd)) 
          st <- paste(st, ";PWD=", pwd, sep = "")
        odbcDriverConnect(st, ...)
      }
}



##########################################################################
##########################################################################
### siGenome library of annotations for Dharmacon siRNA library used
### in screens (e.g. BRCA2 screen Jason Wong,
### L9 hTERT screen Angela Beckett)

get.libraries.siGenome <-
  function( )
{
  ## function to retrieve the whole siGenome library
  ## into a local dataframe.  Network grab of entire database
  ## takes a few seconds; working locally is then very quick.

  require("RODBC")

  connectionAttemptCount <- 0
  while ( (dbChannel <-odbcConnect("shannon", uid="mysql")) < 0) {
    print ("Error opening database")
    connectionAttemptCount <- connectionAttemptCount + 1
    if ( connectionAttemptCount > 1000 ) {
      stop("Too many failed connection attempts.")
    }
  }
  queryString <- "SELECT * FROM libraries.siGenome limit 5"
  valueTable <- sqlQuery( dbChannel, queryString )
  numCols <- ncol(valueTable)
  queryString <- "SELECT * FROM libraries.siGenome"
  ## Tabs appear in some text fields, making tab delimiting impossible.
  ## Commas appear in text fields, making comma separated delimiting impossible.
  ## Replace tabs by <space verticalBar space>
  tabchar <- "\t"
  vbarchar <- " | "
  valueTable <-
    as.data.frame(lapply(sqlQuery( dbChannel, queryString, as.is = seq(numCols) ),
                         function(x) { gsub(tabchar, vbarchar, x) } ),
                  stringsAsFactors = FALSE)
  odbcClose(dbChannel)
  invisible(return( valueTable ))
}

readDatabasedata <-
  function(siName )
{
  ## Function originally set up by Ken Fong to get annotations for
  ## Angela Beckett's Screen2008
  require("RODBC")
  require("DBI")
  require("RMySQL")

  while ( (dbChannel <-odbcConnect("shannon", uid="mysql")) < 0)
    print ("Error opening database")
  queryString <-
    paste("SELECT ",
          "location, molecule_type, chromosome, ",
          "calc1_description, calc2_description, ",
          "calc3_description, calc4_description ",
          "FROM libraries.siGenome where target_refseq ='", siName,"'", sep="")
  ##print (queryString)
  valueTable <- sqlQuery( dbChannel, queryString, as.is = seq(7) )
  odbcClose(dbChannel)
  invisible(return( valueTable ))
} 

merge.siGenome <-
  function(x,
           by.x,
           by.y = "target_refseq",
           ...,
           verbose = FALSE)
{
  ## Function to merge siGenome data with a dataframe
  ## containing a column (by.x) found in the
  ## siGenome database (by.y), "target_refseq" by default.
  ## Example usage:
  ## bar <- merge.siGenome(foo, by.x = "refseq")
  siGdf <- get.libraries.siGenome()
  xblanks <- as.character(x[, by.x]) == ""

  si.xp <- as.character(x[!xblanks, by.x]) %in% siGdf[, by.y]
  
  ## set up data frame to cbind to x
  siGr <- siGdf[1, ]
  is.na(siGr[1, ]) <- seq(ncol(siGr))
  siGcb <- siGr[rep(1, nrow(x)), ]
  
  if (any(si.xp)) {
    ## Note:  This gets the first match only.
    ## (Future development:  If there are
    ##  multiple hits, need to
    ##  determine what else to do.
    ##  Duplicate records with multiple matches?)
    ##
    match.x <- match(as.character(x[!xblanks, by.x]), siGdf[, by.y])
    which.x <- which(!is.na(match.x))
    wherein.y <- match.x[which.x]
    siGcb[!xblanks, ][which.x, ] <- siGdf[wherein.y, ]
    
  } else {
    
    ## No siGenome data found, return original object
    if (verbose) cat("\n\nNo matching data found in siGenome database\n\n")
    
  }

  x <- cbind(x, siGcb)
  invisible(return(x))

}



##########################################################################
##########################################################################


### ### w.l.o.g.  b=0: - perp distance from line y = mx
### distmx <- function(x, y, m)
### {
###   x1 <- (m/(m^2 + 1))*(y + x/m)
###   if (abs(m - 0) < 1e-7) {
###     y
###   } else {
###     sign(( y - (m * x1) )) * sqrt( ( (m * x1) - y)^2 + (x1 - x)^2 )
###   }
### 
### }

distmx  <- function(x, y, m)
{
  ## w.l.o.g.  b=0: - perp distance of (x, y) from line y = mx
  ## or projection (x1, y1) of (x, y) onto y = mx.
  ## Perpendicular to y = mx is y = (-1/m)*x + c
  ## (x1, y1) is point on y = (-1/m)*x + c where y = (-1/m)*x + c
  ## intersects y = mx etc.
  ## y1=mx1
  ## y1=(-1/m)x1+c
  ## y=(-1/m)x+c [1]
  ## Thus
  ## y1-y=(-1/m)(x1-x) [2]
  ## Subtract eqn[1] from [2] to get
  ## mx1+x1/m = y+x/m etc.
  if ( length(m) != 1 ) stop("slope m must be scalar")
  
  if (abs(m) < 1e-7) {
    y
  } else {
    if (abs(m) > 1e+7) {
      x
    } else {
      ## x1 <- (m/(m^2 + 1))*(y + x/m)
      ## dy <- y - (m * x1)
      ## sign(dy) * sqrt( dy^2 + (x1 - x)^2 )
      ## A <- 1/(m^2 + 1) * matrix(c(1, m, m, m^2), ncol = 2)
      ## AmI <- 1/(m^2 + 1) * matrix(c(-(m^2), m, m, -1), ncol = 2)
      ## mAmI <- 1/(m^2 + 1) * matrix(c((m^2), -m, -m, 1), ncol = 2) ## to get positive values above line.
      dm <- ((1/(m^2 + 1) * matrix(c((m^2), -m, -m, 1), ncol = 2)) %*% rbind(x, y))
      sign(dm[2,]) * sqrt(colSums(dm^2))
    }
  }
}

##########################################################################
##########################################################################
### See formula for Tn,3 (Klotz analog) on p210 of
### M.A. Fligner and T.J. Killeen (1976) "Distribution-Free Two-Sample
### Tests for Scale
###
### SM mods to get the components of the statistic so as to identify
### the observations yielding excessive variability.  See resSq below.
### TODO: Make a request on Rdevel for adding such output to the function.
###
###

fligner.residuals <- function(x, ...) UseMethod("fligner.residuals")


fligner.residuals.formula <-
function(formula, data, subset, na.action, ...)
{
    if(missing(formula) || (length(formula) != 3))
        stop("'formula' missing or incorrect")
    m <- match.call(expand.dots = FALSE)
    if(is.matrix(eval(m$data, parent.frame())))
        m$data <- as.data.frame(data)
    m[[1L]] <- as.name("model.frame")
    mf <- eval(m, parent.frame())
    DNAME <- paste(names(mf), collapse = " by ")
    names(mf) <- NULL
    y <- do.call("fligner.residuals", as.list(mf))
    y$data.name <- DNAME
    y
}

fligner.residuals.default <-
function(x, g, ...)
{
    ## FIXME: This is the same code as in kruskal.test(), and could also
    ## rewrite bartlett.test() accordingly ...
    if (is.list(x)) {
        if (length(x) < 2)
            stop("'x' must be a list with at least 2 elements")
        DNAME <- deparse(substitute(x))
        x <- lapply(x, function(u) u <- u[complete.cases(u)])
        k <- length(x)
        l <- sapply(x, "length")
        if (any(l == 0))
            stop("all groups must contain data")
        g <- factor(rep(1 : k, l))
        x <- unlist(x)
    }
    else {
        if (length(x) != length(g))
            stop("'x' and 'g' must have the same length")
        DNAME <- paste(deparse(substitute(x)), "and",
                       deparse(substitute(g)))
        OK <- complete.cases(x, g)
        x <- x[OK]
        g <- g[OK]
        if (!all(is.finite(g)))
            stop("all group levels must be finite")
        g <- factor(g)
        k <- nlevels(g)
        if (k < 2)
            stop("all observations are in the same group")
    }
    n <- length(x)
    if (n < 2)
        stop("not enough observations")
    ## FIXME: now the specific part begins.

    ## Careful. This assumes that g is a factor:
    x <- x - tapply(x,g,median)[g]

    a <- qnorm((1 + rank(abs(x)) / (n + 1)) / 2)
    resSq <- tapply(a, g, "sum")^2
    STATISTIC <- sum(tapply(a, g, "sum")^2 / tapply(a, g, "length"))
    STATISTIC <- (STATISTIC - n * mean(a)^2) / var(a)
    PARAMETER <- k - 1
    PVAL <- pchisq(STATISTIC, PARAMETER, lower.tail = FALSE)
    names(STATISTIC) <- "Fligner-Killeen:med chi-squared"
    names(PARAMETER) <- "df"
    METHOD <- "Fligner-Killeen test of homogeneity of variances"

    RVAL <- list(statistic = STATISTIC,
                 parameter = PARAMETER,
                 p.value = PVAL,
                 method = METHOD,
                 data.name = DNAME,
                 resSq = resSq)
    class(RVAL) <- "htest"
    return(RVAL)
}

##########################################################################
##########################################################################
ones <- function(which.1, length.) {
  ## Generate an indicator vector with ones in each position shown in which
  one <- rep(0, length.)
  one[which.1] <- 1
  one
}

capwords <- function(s, strict = FALSE) {
    cap <- function(s) paste(toupper(substring(s,1,1)),
                  {s <- substring(s,2); if(strict) tolower(s) else s},
                             sep = "", collapse = " " )
    sapply(strsplit(s, split = " "), cap, USE.NAMES = !is.null(names(s)))
}
is.odd <- function(x) x%%2 == 1
is.even <- function(x) x%%2 == 0


##########################################################################
##########################################################################


##########################################################################
##########################################################################


##########################################################################
##########################################################################


##########################################################################
##########################################################################


##########################################################################
##########################################################################


