#' Calculate MBid.new based on given ID.
#' @param x METABRIC ID
#' @export
setMBid <- function(x) {
  # Substitute a period for minus and underscore, then drop ".MB." suffix
  xu <- toupper(x)
  xr <- stringr::str_replace_all(xu, c(
    "-|_" = "\\.",
    "MT\\.MB" = "MB\\.MT",
    "MB\\." = ""
  ))

  # Extract final digits
  posdot <- unlist(regexec("\\.", xr))
  xrrs <- xr
  idxs <- which(posdot > 0)
  if (length(idxs)) {
    xrrs[idxs] <- substring(xr[idxs], posdot[idxs] + 1)
  }

  # Add 6000 for Manitoba and Guy's
  xn <- as.numeric(xrrs)
  sidxs <- grep("MT|GU", xu)
  if (length(sidxs)) {
    xn[sidxs] <- xn[sidxs] + 6000
  }
  MBid.new <- paste0("MB.", formatC(xn, width = 4, flag = "0"))
  return(MBid.new)
}

#' Take in any ID coding and return treatment centre
#' @inheritParams setMBid
#' @export
MBid2Ctr <- function(x) {
  if (any(is.na(as.numeric(gsub("MB\\.", "", x))))) {
    stop("x must be MBid")
  }
  cut(as.numeric(gsub("MB\\.", "", toupper(x))),
      c(0, 2000, 4000, 6000, 7000, 10000) - 1,
      labels = c("AD", "NT", "VC", "MT", "GU"))
}

#' Row match with annodf
#' @noRd
refSeqRowMatches_annodf <- function(pattern, cols, annodf) {
  rsidxs <- pattern %>%
    purrr::map(
      ~ cols %>%
        purrr::map(function(y) {
          pattrn <- strsplit(.x, split = "\\.")[[1]][1]  # Strip decimal from end of RefSeq ID
          grep(pattern = paste0("^", pattrn, "$|^", pattrn, "\\."), x = annodf[[y]])
        }) %>%
        unlist() %>%
        unique())
  return(rsidxs)
}

#' Set the biological significance variable in output data
#'
#' Modify the data object's biological significance variable based on
#' fold change and false discovery rate thresholds.
#'
#' The default minimum fold change of biological significance is 1.25 and the
#' false discovery rate set to 0.01. One of three conditions based on threshold
#' of the explanatory variable (e.g. age cutoff) must be true for biological
#' significance: fold change greater than its biological significance constant
#' and adjusted p-value less than false discovery rate for either the lower
#' cutoff, upper cutoff, or the entire range of the explanatory variable.
#'
#' @param data aroutdf data
#' @param var variable name of biological significance
#' @param slopes slope variable names for Less than or Equal, Greater Than, and
#'   All cases
#' @param pvalues adjusted p-value variable names for Less than or Equal,
#'   Greater Than, and All cases
#' @param fc fold change
#' @param fdr false discovery rate
#'
#' @return modified data object
#' @export
metabric_signif <- function(data, var, slopes = NULL, pvalues = NULL,
                            fc = 1.25, fdr = 0.01) {
  s <- slopes %||% c("LE_slope", "GT_slope", "All_slope") %>%
    rlang::syms()
  p <- pvalues %||% c("LE_pval_BHadj", "GT_pval_BHadj", "All_pval_BHadj") %>%
    rlang::syms()
  assertthat::assert_that(length(s) == 3, length(p) == 3)
  biosigLE <- biosigGT <- log2(fc) / 35
  biosigAll <- log2(fc) / 70
  dplyr::mutate(data, !!var :=
                  (abs(!!s[[1]]) > biosigLE & (!!p[[1]]) < fdr) |
                  (abs(!!s[[2]]) > biosigGT & (!!p[[2]]) < fdr) |
                  (abs(!!s[[3]]) > biosigAll & (!!p[[3]]) < fdr))
}

#' Add arGeneSet variables to aroutdf
#'
#' @param x aroutdf object
#' @param aridxs ar gene set
#' @param annodf annotation data
#' @param age age threshold for calculating biological significance
#' @param fdr false discovery rate level
#'
#' @return extra variables added to `x`. Nothing is done if `x` had no
#'   `BHadj_and_AgeDependentp` probes.
#' @export
metabric_ar <- function(x, aridxs, annodf, age = 60, fdr = 0.01) {
  if (nrow(x) == 0) {
    return(x)
  }
  # Specify age-dependent variable names
  LE_pval <- sym_var(age, "LE", "pval")
  GT_pval <- sym_var(age, "GT", "pval")
  arGeneSet_LE_BHadj_pval <- sym_var(age, "arGeneSet_LE", "BHadj_pval")
  arGeneSet_GT_BHadj_pval <- sym_var(age, "arGeneSet_GT", "BHadj_pval")
  LE_slope <- sym_var(age, "LE", "slope")
  GT_slope <- sym_var(age, "GT", "slope")
  # Add variables
  x %>%
    dplyr::mutate(
      !!"arGeneSetidxp" := .data$ProbeId %in% annodf$Probe_id[aridxs],
      !!arGeneSet_LE_BHadj_pval := p.adjust(value_if(!!LE_pval, .data$arGeneSetidxp), method = "BH"),
      !!arGeneSet_GT_BHadj_pval := p.adjust(value_if(!!GT_pval, .data$arGeneSetidxp), method = "BH"),
      !!"arGeneSet_AllAges_BHadj_pval" := p.adjust(value_if(.data$AllAges_pval, .data$arGeneSetidxp), method = "BH")
    ) %>%
    metabric_signif(
      var = "arGeneSet_BHadj_and_AgeDependentp",
      slopes = as.character(c(LE_slope, GT_slope, "AllAges_slope")),
      pvalues = as.character(c(arGeneSet_LE_BHadj_pval, arGeneSet_GT_BHadj_pval, "arGeneSet_AllAges_BHadj_pval")),
      fdr = fdr
    )
}

#' Add additional ER binding gene lists to aroutdf
#'
#' @param x aroutdf object
#' @param ebdf_t1 Tier 1 ER binding gene set from NKI
#' @param ebdf_t2 Tier 2 ER binding gene set from NKI
#'
#' @return extra variables added to `x`
#' @export
metabric_ebdf <- function(x, ebdf_t1, ebdf_t2) {
  if (nrow(x) == 0) {
    x %>%
      dplyr::mutate(
        !!"ERbinding_T1" := character(0),
        !!"ERbinding_T2" := character(0)
      )
  } else {
    x %>%
      dplyr::mutate(
        !!"ERbinding_T1" := ifelse(.data$Gene_symbol %in% purrr::discard(ebdf_t1$Symbol, is.na), TRUE, FALSE),
        !!"ERbinding_T2" := ifelse(.data$Gene_symbol %in% purrr::discard(ebdf_t2$Symbol, is.na), TRUE, FALSE)
      )
  }
}

#' Add evcp variable
#'
#' Set conditions for highligting METABRIC volcano plot points
#'
#' @param x aroutdf object
#' @param thresholds a vector of length six, for three sets of logFC and
#'   BH-adjusted p-value conditions. The 1st and 2nd element comprise the first
#'   condition, the 3rd and 4th element comprise the second condition, the 5th
#'   and 6th condition comprise the third condition.
#' @export
metabric_evcp <- function(x, thresholds) {
  th <- thresholds
  x %>%
    dplyr::mutate(
      !!"evcp" :=
        (abs(.data$Best_log2FC) > th[1] & .data$PBHadj_log > th[2]) |
        (abs(.data$Best_log2FC) > th[3] & .data$PBHadj_log > th[4]) |
        (abs(.data$Best_log2FC) > th[5] & .data$PBHadj_log > th[6])
    )
}

#' Make aroutdf output object
#'
#' @param data clinical data
#' @param filename file name
#' @param annodf annotation data
#' @param ebdf ER binding genes
#' @param Dataset_r probe data
#' @param age age cutoff for analysis. Defaults to 60.
#' @param fdr false discovery rate. Defaults to 0.01.
#' @param fc fold change. Defaults to 1.25, 2, and 4 (3 sets of results).
#' @param group if `NULL`, results are for all cases. Otherwise, the variable
#'   name for which to split `data` by.
#'
#' @return aroutdf object used for determining age-dependent trends
#' @export
metabric_aroutdf <- function(data, filename, annodf, ebdf, Dataset_r, age = 60,
                             fdr = 0.01, fc = c(1.25, 2, 4), group = NULL) {
  np <- nrow(annodf) # number of probes
  co_names <- paste0(c("LE", "GT"), age)
  aroutmatcolnames <-
    purrr::cross2(c(co_names, "AllAges"), c("slope", "pval")) %>%
    purrr::map_chr(paste, collapse = "_") %>%
    c("AgeDependentp") # additional column names

  # Loop over fc
  for (i in fc) {
    pb <- progress::progress_bar$new(total = np, clear = FALSE)
    aroutdf <- annodf
    biosigslopeLE <- biosigslopeGT <- log2(i) / 35
    biosigslopeAllAges <- log2(i) / 70
    multcompPval <- fdr / (2 * nrow(aroutdf))
    aroutmat <- matrix(NA_real_, nrow = np, ncol = length(aroutmatcolnames),
                       dimnames = list(aroutdf$ProbeId, aroutmatcolnames))
    AgeDependentp_col <- match("AgeDependentp", aroutmatcolnames)
    aroutdf[aroutmatcolnames[-AgeDependentp_col]] <- rep(NA_real_, np)
    aroutdf[aroutmatcolnames[AgeDependentp_col]] <- rep(NA, np)
    arlmdf <- data.frame(age_at_diagnosis = data$age_at_diagnosis)

    # Loop over each probe
    for (ni in seq_len(np)) {
      pb$tick()
      psi <- aroutdf$ProbeId[ni]
      arlmdf$probesetni <- Dataset_r[match(data$MBid, rownames(Dataset_r)),
                                     match(psi, colnames(Dataset_r))]
      aroutmat[ni, ] <- with(arlmdf, lapply(list(age_at_diagnosis <= age, age_at_diagnosis > age, NULL), function(s)
        lm(probesetni ~ age_at_diagnosis, data = arlmdf, na.action = na.exclude, subset = s))) %>%
        lapply(broom::tidy) %>%
        dplyr::bind_rows() %>%
        magrittr::extract(.$term %in% "age_at_diagnosis", c("estimate", "p.value")) %>%
        purrr::flatten_dbl() %>%
        c((abs(.[1]) > biosigslopeLE ||
             abs(.[2]) > biosigslopeGT ||
             abs(.[3]) > biosigslopeAllAges) &&
            (any(.[4:6] < multcompPval)))
    }
    aroutdf[, aroutmatcolnames] <- aroutmat

    # Set variable names
    LE_pval <- sym_var(age, "LE", "pval")
    GT_pval <- sym_var(age, "GT", "pval")
    LE_BHadj_pval <- sym_var(age, "LE", "BHadj_pval")
    GT_BHadj_pval <- sym_var(age, "GT", "BHadj_pval")
    LE_slope <- sym_var(age, "LE", "slope")
    GT_slope <- sym_var(age, "GT", "slope")
    LE_log2FC <- sym_var(age, "LE", "log2FC")
    GT_log2FC <- sym_var(age, "GT", "log2FC")
    LE_Bestp <- sym_var(age, "LE", "Bestp")
    GT_Bestp <- sym_var(age, "GT", "Bestp")

    # Calculate statistics
    aroutdf <- aroutdf %>%
      dplyr::mutate(
        !!LE_BHadj_pval := p.adjust(!!LE_pval, method = "BH"),
        !!GT_BHadj_pval := p.adjust(!!GT_pval, method = "BH"),
        !!"AllAges_BHadj_pval" := p.adjust(.data$AllAges_pval, method = "BH"),
        !!"BHadj_and_AgeDependentp" := (abs(!!LE_slope) > biosigslopeLE & !!LE_BHadj_pval < fdr) |
          (abs(!!GT_slope) > biosigslopeGT & !!GT_BHadj_pval < fdr) |
          (abs(.data$AllAges_slope) > biosigslopeAllAges & .data$AllAges_BHadj_pval < fdr),
        !!"BHadj_signifp" := !!LE_BHadj_pval < fdr | !!GT_BHadj_pval < fdr | .data$AllAges_BHadj_pval < fdr,
        !!LE_log2FC := !!LE_slope * 35,
        !!GT_log2FC := !!GT_slope * 35,
        !!"AllAges_log2FC" := .data$AllAges_slope * 70,
        !!LE_Bestp := abs(!!LE_slope) > biosigslopeLE & !!LE_BHadj_pval < fdr,
        !!GT_Bestp := abs(!!GT_slope) > biosigslopeGT & !!GT_BHadj_pval < fdr &
          abs(!!GT_slope) > abs(!!LE_slope),
        !!"AllAges_Bestp" := abs(.data$AllAges_slope) > biosigslopeAllAges & .data$AllAges_BHadj_pval < fdr &
          (abs(.data$AllAges_log2FC) > abs(!!LE_log2FC) | abs(.data$AllAges_log2FC) > abs(!!GT_log2FC)),
        !!"Best_log2FC" := dplyr::case_when(
          .data$AllAges_Bestp ~ .data$AllAges_log2FC,
          !!GT_Bestp ~ !!GT_log2FC,
          !!LE_Bestp ~ !!LE_log2FC,
          TRUE ~ .data$AllAges_log2FC
        ),
        !!"Best_BHadj_pval" := dplyr::case_when(
          .data$AllAges_Bestp ~ .data$AllAges_BHadj_pval,
          !!GT_Bestp ~ !!GT_BHadj_pval,
          !!LE_Bestp ~ !!LE_BHadj_pval,
          TRUE ~ .data$AllAges_BHadj_pval
        ),
        !!"ERbinding" := ifelse(.data$Ensembl_gene_id %in% purrr::discard(ebdf$ensembl_gene_id, is.na), TRUE, FALSE)) %>%
      dplyr::select(-!!LE_Bestp, -!!GT_Bestp, -.data$AllAges_Bestp) %>%
      dplyr::filter(.data$BHadj_and_AgeDependentp)
    if (is.null(group)) {
      g <- "AllCases"
    } else {
      g <- unique(data[[group]])
    }
    utils::write.csv(x = aroutdf, file = glue::glue(filename))
  }
}
