# magrittr placeholder
globalVariables(".")

# global environment
pos <- 1

#' Turn colour character string to hexadecimal form with alpha transparency
#' @param col colour
#' @param alpha alpha transparency value. Ranges from 0 to 255.
#' @noRd
col2rgba <- function(col, alpha = 30) {
  rgb(t(col2rgb(col)), alpha = alpha, maxColorValue = 255)
}

#' value at index if TRUE, otherwise return real NA
#' @param value numeric vector of values
#' @param index logical vector same length as `value` used for indexing
#' @noRd
value_if <- function(value, index) {
  purrr::map2_dbl(value, index, ~ ifelse(.y, .x[.y], NA_real_))
}

#' Tidy gene names
#'
#' Extract gene names from ER binding gene lists.
#'
#' Gene names with the empty string `""` or `NA` are removed. Duplicate gene
#' names are removed and finally the gene names are sorted.
#'
#' @param data ER binding gene dataset
#' @param var variable name with gene symbols in `data`
#' @export
tidy_genes <- function(data, var) {
  data[[var]] %>%
    `[`(!(is.na(.) | . == "")) %>%
    unique() %>%
    sort()
}

#' Convert strings for use in file names
#'
#' Certain characters are not advisable for use in file names. `str_decimal`
#' converts decimal numbers and `str_sign` converts positive and negative signs.
#'
#' Decimal numbers contain a period character ".", which is traditionally used
#' to separate the name and extension of a file. `str_decimal` replaces all
#' periods with "p" (for "period").
#'
#' The plus sign "+", minus sign "-", and division sign "/" are all not
#' recommended for use in file names. There are two syntaxes used for
#' replacement. In the short version, they are replaced by "p", "n", and "_",
#' respectively. In the long version, they are replaced by "pos" (for
#' "positive"), "neg" (for "negative"), and "", respectively.
#' @param string character string
#' @name str_file
#' @export
#' @examples
#' str_decimal(1.23)
#' str_sign("ER+/HER2-")
#' str_sign("ER+/HER2-", type = "long")
str_decimal <- function(string) {
  gsub("\\.", "p", as.character(string))
}

#' @inheritParams str_decimal
#' @param type use "short" or "long" type of conversion
#' @name str_file
#' @export
str_sign <- function(string, type = c("short", "long")) {
  type <- match.arg(type)
  pattern <- switch(
    type,
    short = c("\\+" = "p", "\\-" = "n", "\\/" = "_"),
    long = c("\\+" = "pos", "\\-" = "neg", "\\/" = "")
  )
  stringr::str_replace_all(string, pattern)
}

#' Turn a variable name into a symbol for tidy evaluation specification in
#' tcga_aroutdf
#' @noRd
sym_var <- function(age, direction, name) {
  rlang::sym(paste0(direction, age, "_", name))
}
